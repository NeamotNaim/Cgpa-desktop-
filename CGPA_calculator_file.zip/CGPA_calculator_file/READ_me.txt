
* The application is located in "Application"  folder
* The source file is located in "CGPA_calculator(source)" 
* For run in  netbean :first open the source code as open project,then run the Main_frame.java
  go to this path ~ CGPA_calculator(source)/src/cgpa_calculator/Main_frame.java.